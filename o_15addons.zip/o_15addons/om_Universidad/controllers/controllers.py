# -*- coding: utf-8 -*-
# from odoo import http


# class Colegioamericano.(http.Controller):
#     @http.route('/colegioamericano./colegioamericano.', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/colegioamericano./colegioamericano./objects', auth='public')
#     def list(self, **kw):
#         return http.request.render('colegioamericano..listing', {
#             'root': '/colegioamericano./colegioamericano.',
#             'objects': http.request.env['colegioamericano..colegioamericano.'].search([]),
#         })

#     @http.route('/colegioamericano./colegioamericano./objects/<model("colegioamericano..colegioamericano."):obj>', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('colegioamericano..object', {
#             'object': obj
#         })
