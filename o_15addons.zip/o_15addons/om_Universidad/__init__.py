
{
'name': 'Wolftec',
'version': '1.0.0',
'category': 'Game',
'summary': 'Tecno',
'description': 'Tecnologia Cuatum',
'depends': [],
'data': [],
'demo': [],
'installable': True,
'auto_install': False,
'license': 'LGPL-3',
}